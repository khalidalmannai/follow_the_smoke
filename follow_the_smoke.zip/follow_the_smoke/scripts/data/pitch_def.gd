class_name PitchDef
extends Resource
## A place in the aisle the player can rent for a night (GDD 6).

@export var id: StringName
@export var display_name: String
## Passers-by per minute at this pitch.
@export var traffic_per_min: float = 12.0
@export var rent_per_night: int = 40
## 0-1: how much of a stall's pull reaches the aisle here (corners hide you).
@export_range(0.0, 1.0, 0.05) var visibility: float = 0.8
## Hard cap on queue length (GDD 5.1 rule 3).
@export var queue_cap: int = 8
## Above this the queue looks crowded and people hesitate (visual only for now).
@export var queue_soft_limit: int = 5
