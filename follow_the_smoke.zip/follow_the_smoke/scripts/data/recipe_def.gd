class_name RecipeDef
extends Resource
## A dish (GDD 5.3). Every recipe trades pull against speed.

@export var id: StringName
@export var display_name: String
@export var cuisine_tags: PackedStringArray = PackedStringArray()
@export var cook_time_s: float = 10.0
## 0-1 pull while this dish is cooking.
@export_range(0.0, 1.0, 0.05) var aroma_strength: float = 0.5
@export var aroma_radius_px: float = 160.0
## Burst pull from a well-timed show action (0 = no show action).
@export_range(0.0, 1.0, 0.05) var show_burst: float = 0.0
@export var price: int = 6
@export var ingredient_cost: int = 2
