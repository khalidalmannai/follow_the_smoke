class_name CustomerTypeDef
extends Resource
## A passer-by archetype (GDD 5.1). All weights apply to inputs normalised to 0-1.

@export var id: StringName
@export var display_name: String

@export_group("Selection weights")
@export_range(0.0, 2.0, 0.05) var w_aroma: float = 1.0
@export_range(0.0, 2.0, 0.05) var w_show: float = 0.6
@export_range(0.0, 2.0, 0.05) var w_queue: float = 0.3
@export_range(0.0, 2.0, 0.05) var w_frontage: float = 0.6
@export_range(0.0, 2.0, 0.05) var w_menu: float = 0.5
@export_range(0.0, 2.0, 0.05) var w_price: float = 0.5
@export_range(0.0, 2.0, 0.05) var w_wait: float = 0.3

@export_group("Behaviour")
## Seconds this customer will stand in a queue before leaving.
@export var patience_s: float = 60.0
## Weighted pull a stall must reach before this passer-by notices it.
@export_range(0.0, 2.0, 0.01) var notice_threshold: float = 0.35
## Minimum utility U for a stall to be worth choosing at all.
@export_range(-2.0, 2.0, 0.01) var min_utility: float = 0.3
## Noise amplitude as a fraction of the top score (GDD: about 5-10%).
@export_range(0.0, 0.3, 0.01) var noise_fraction: float = 0.08
@export var group_size_min: int = 1
@export var group_size_max: int = 1
## Cuisine tags this type likes; matched against a stall's menu (the D term).
@export var tastes: PackedStringArray = PackedStringArray()
## Relative share of the crowd made up of this type.
@export var spawn_weight: float = 1.0
