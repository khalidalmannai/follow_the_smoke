class_name RivalDef
extends Resource
## A rival stall's fixed profile (GDD 5.2). No cooking, inventory or ingredients.

@export var id: StringName
@export var display_name: String
@export_range(0.0, 1.0, 0.05) var aroma: float = 0.5
@export_range(0.0, 1.0, 0.05) var show: float = 0.2
@export_range(0.0, 1.0, 0.05) var frontage: float = 0.5
## 0 = cheapest in the market, 1 = most expensive.
@export_range(0.0, 1.0, 0.05) var price_level: float = 0.5
@export var serve_interval_s: float = 12.0
@export var avg_ticket: int = 6
@export var menu_tags: PackedStringArray = PackedStringArray()
@export_range(0.0, 1.0, 0.05) var visibility: float = 0.8
@export var queue_cap: int = 8
