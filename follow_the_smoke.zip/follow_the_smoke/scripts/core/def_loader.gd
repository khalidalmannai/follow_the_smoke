class_name DefLoader
extends RefCounted
## Loads every .tres/.res resource in a folder. Static so headless tools can use
## it without the DataManager autoload (autoloads don't run under --script).


static func load_dir(path: String) -> Array[Resource]:
	var out: Array[Resource] = []
	var dir := DirAccess.open(path)
	if dir == null:
		push_error("DefLoader: cannot open %s" % path)
		return out
	var files := dir.get_files()
	files.sort()
	for f in files:
		# Exported builds rename resources to *.remap; strip that suffix.
		var name := f.trim_suffix(".remap")
		if name.ends_with(".tres") or name.ends_with(".res"):
			var res := load(path.path_join(name))
			if res != null:
				out.append(res)
	return out


static func load_by_id(path: String) -> Dictionary:
	var out := {}
	for r in load_dir(path):
		out[r.get("id")] = r
	return out
