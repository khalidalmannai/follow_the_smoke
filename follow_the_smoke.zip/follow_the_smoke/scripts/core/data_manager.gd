extends Node
## Autoload: loads all content definitions once at startup (GDD 9).
## Look things up by id, e.g. DataManager.customers[&"stroller"].

const CUSTOMERS_DIR := "res://data/customers"
const PITCHES_DIR := "res://data/pitches"
const RIVALS_DIR := "res://data/rivals"
const RECIPES_DIR := "res://data/recipes"

var customers: Dictionary = {}
var pitches: Dictionary = {}
var rivals: Dictionary = {}
var recipes: Dictionary = {}


func _ready() -> void:
	reload()


func reload() -> void:
	customers = DefLoader.load_by_id(CUSTOMERS_DIR)
	pitches = DefLoader.load_by_id(PITCHES_DIR)
	rivals = DefLoader.load_by_id(RIVALS_DIR)
	recipes = DefLoader.load_by_id(RECIPES_DIR)
