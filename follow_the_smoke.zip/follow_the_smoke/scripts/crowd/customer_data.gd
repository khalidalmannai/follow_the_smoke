class_name CustomerData
extends RefCounted
## Plain-data snapshot of one passer-by. No scene access, so StallSelector can
## run on thousands of these headlessly (GDD 9).

var type: CustomerTypeDef
## Per-customer seed. Drives the selection noise, so a night replays exactly.
var seed: int = 0
var group_size: int = 1


static func create(p_type: CustomerTypeDef, p_seed: int, p_group_size: int = 1) -> CustomerData:
	var c := CustomerData.new()
	c.type = p_type
	c.seed = p_seed
	c.group_size = max(1, p_group_size)
	return c


## Deterministic value in [-1, 1] for this customer and a given stall.
## Independent of evaluation order, so adding a stall never reshuffles the others.
func noise_for(stall_id: StringName) -> float:
	var h: int = hash(str(seed) + ":" + String(stall_id))
	return float(posmod(h, 20001)) / 10000.0 - 1.0
