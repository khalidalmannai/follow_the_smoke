class_name StallData
extends RefCounted
## Plain-data snapshot of one stall as a given passer-by sees it right now.
## Player and rival stalls use the same shape (GDD 9: one shared Stall scene).
## Every pull input is already normalised to 0-1.

var id: StringName
var is_player: bool = false

## Pull sources, 0-1.
var aroma: float = 0.0
var show: float = 0.0
var frontage: float = 0.0

## Queue state.
var queue_length: int = 0
var queue_cap: int = 8
## Average seconds to serve one customer at this stall.
var avg_serve_s: float = 10.0

## 0 = cheapest in the market, 1 = most expensive.
var price_level: float = 0.5
var menu_tags: PackedStringArray = PackedStringArray()

## 0-1: how much of this stall's pull reaches this passer-by
## (distance falloff x pitch visibility). The caller computes it.
var reach: float = 1.0


func is_full() -> bool:
	return queue_length >= queue_cap


func expected_wait_s() -> float:
	return float(queue_length) * avg_serve_s
