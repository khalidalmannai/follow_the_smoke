class_name SelectionResult
extends RefCounted
## What one passer-by decided, plus enough detail to classify the outcome
## for the end-of-night report (GDD 4: the five crowd outcomes).

## The stall they chose, or null if they walked past everyone.
var chosen: StallData = null
## Stalls they noticed (perceived pull >= their threshold).
var noticed: Array[StallData] = []
## Noticed stalls that were real options: not full and U >= min_utility.
var viable: Array[StallData] = []
## Final utility (noise included) per noticed stall id.
var utilities: Dictionary = {}


func walked_past() -> bool:
	return chosen == null


func was_viable(stall_id: StringName) -> bool:
	for s in viable:
		if s.id == stall_id:
			return true
	return false


## True if at least one stall other than `stall_id` was also a real option.
func had_rival_option(stall_id: StringName) -> bool:
	for s in viable:
		if s.id != stall_id:
			return true
	return false
