class_name NightSimulator
extends RefCounted
## Headless, deterministic simulation of one night in the aisle: passers-by
## arrive, notice stalls, choose one (StallSelector), queue, get served or give
## up. No graphics. Used for tuning weights before anything is drawn, and as a
## reference for the in-game Market scene.

## How long a show burst takes to fade out, and how much cooking time it costs.
const SHOW_DECAY_S := 3.0
const SHOW_TIME_COST_S := 1.5
## A stall that isn't cooking (empty queue) gives off only this share of its aroma.
const IDLE_AROMA_SHARE := 0.4


class PlayerConfig:
	var aroma := 0.7
	var frontage := 0.3
	var price_level := 0.5
	var serve_interval_s := 12.0
	var avg_ticket := 7
	var menu_tags := PackedStringArray(["asian"])
	## 0 = never use show actions.
	var show_every_s := 0.0
	var show_burst := 0.8
	## Share of aroma kept with an empty queue. 1.0 = keep the grill going to
	## attract people (in the game this costs ingredients; not modelled yet).
	var idle_aroma_share := IDLE_AROMA_SHARE


class Stall:
	var id: StringName
	var is_player := false
	var aroma := 0.5
	var frontage := 0.5
	var price_level := 0.5
	var serve_interval_s := 10.0
	var avg_ticket := 6
	var menu_tags := PackedStringArray()
	var visibility := 0.8
	var queue_cap := 8
	## Constant show pull (rivals); the player's comes from bursts instead.
	var show_base := 0.0
	var show_burst := 0.0
	var show_every_s := 0.0
	var idle_aroma_share := IDLE_AROMA_SHARE

	var show_level := 0.0
	var next_show_t := 0.0
	var serve_timer := 0.0
	var queue: Array = []  # of Dictionary {customer, join_t, outcome}
	var served := 0
	var revenue := 0
	var abandoned := 0
	var queue_time_sum := 0.0
	var max_queue := 0

	func snapshot() -> StallData:
		var d := StallData.new()
		d.id = id
		d.is_player = is_player
		d.aroma = aroma if not queue.is_empty() else aroma * idle_aroma_share
		d.show = maxf(show_level, show_base)
		d.frontage = frontage
		d.queue_length = queue.size()
		d.queue_cap = queue_cap
		d.avg_serve_s = serve_interval_s
		d.price_level = price_level
		d.menu_tags = menu_tags
		d.reach = visibility
		return d


var customer_types: Array = []  # of CustomerTypeDef
var pitch: PitchDef
var player := PlayerConfig.new()
var rivals: Array = []  # of RivalDef
var night_length_s := 360.0
var dt := 0.25
var seed := 1


## Runs one night and returns a report Dictionary.
func run() -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed

	var stalls: Array = [_make_player_stall()]
	for r in rivals:
		stalls.append(_make_rival_stall(r))

	var outcomes := {
		"won_from_rival": 0,
		"won_uncontested": 0,
		"lost_to_rival": 0,
		"walked_past_everyone": 0,
		"abandoned_your_queue": 0,
		"went_elsewhere_uncontested": 0,
	}
	var passers := 0
	var arrivals_per_s := pitch.traffic_per_min / 60.0
	var total_weight := 0.0
	for t in customer_types:
		total_weight += t.spawn_weight

	var t := 0.0
	while t < night_length_s:
		# 1. Arrivals (Bernoulli per tick; dt keeps the chance well below 1).
		if rng.randf() < arrivals_per_s * dt:
			passers += 1
			var ctype := _pick_type(rng, total_weight)
			var c := CustomerData.create(ctype, rng.randi(),
				rng.randi_range(ctype.group_size_min, ctype.group_size_max))
			var snaps: Array[StallData] = []
			for s in stalls:
				snaps.append(s.snapshot())
			var res := StallSelector.select(c, snaps)
			var outcome := _classify(res)
			if outcome == "walked_past_everyone" or outcome == "went_elsewhere_uncontested" or outcome == "lost_to_rival":
				outcomes[outcome] += 1
			if res.chosen != null:
				var target = _find(stalls, res.chosen.id)
				target.queue.append({"customer": c, "join_t": t, "outcome": outcome})
				target.max_queue = max(target.max_queue, target.queue.size())

		# 2. Show actions (player only for now) and decay.
		for s in stalls:
			if s.show_every_s > 0.0 and t >= s.next_show_t and not s.queue.is_empty():
				s.show_level = s.show_burst
				s.serve_timer -= SHOW_TIME_COST_S
				s.next_show_t = t + s.show_every_s
			s.show_level = maxf(0.0, s.show_level - s.show_burst * dt / SHOW_DECAY_S)

		# 3. Serving and patience.
		for s in stalls:
			s.queue_time_sum += s.queue.size() * dt
			if s.queue.is_empty():
				s.serve_timer = 0.0
			else:
				s.serve_timer += dt
				var head: Dictionary = s.queue[0]
				var group: int = head.customer.group_size
				var need: float = s.serve_interval_s * (1.0 + 0.3 * (group - 1))
				if s.serve_timer >= need:
					s.queue.pop_front()
					s.serve_timer = 0.0
					_count_served(s, head, outcomes)
			var i: int = s.queue.size() - 1
			while i >= 0:
				var e: Dictionary = s.queue[i]
				if t - e.join_t > e.customer.type.patience_s:
					s.queue.remove_at(i)
					s.abandoned += 1
					if s.is_player:
						outcomes["abandoned_your_queue"] += 1
				i -= 1
		t += dt

	# Anyone still queuing at closing gets served.
	for s in stalls:
		while not s.queue.is_empty():
			_count_served(s, s.queue.pop_front(), outcomes)

	var stall_reports := []
	for s in stalls:
		stall_reports.append({
			"id": s.id,
			"served": s.served,
			"revenue": s.revenue,
			"abandoned": s.abandoned,
			"avg_queue": s.queue_time_sum / night_length_s,
			"max_queue": s.max_queue,
		})
	return {"passers": passers, "outcomes": outcomes, "stalls": stall_reports}


func _count_served(s: Stall, entry: Dictionary, outcomes: Dictionary) -> void:
	var group: int = entry.customer.group_size
	s.served += 1
	s.revenue += s.avg_ticket * group
	if s.is_player:
		outcomes[entry.outcome] += 1


## The five crowd outcomes, seen from the player's stall (GDD 4).
static func _classify(res: SelectionResult) -> String:
	if res.walked_past():
		return "walked_past_everyone"
	if res.chosen.is_player:
		return "won_from_rival" if res.had_rival_option(res.chosen.id) else "won_uncontested"
	for s in res.viable:
		if s.is_player:
			return "lost_to_rival"
	return "went_elsewhere_uncontested"


func _pick_type(rng: RandomNumberGenerator, total_weight: float) -> CustomerTypeDef:
	var roll := rng.randf() * total_weight
	for ty in customer_types:
		roll -= ty.spawn_weight
		if roll <= 0.0:
			return ty
	return customer_types[-1]


func _find(stalls: Array, id: StringName):
	for s in stalls:
		if s.id == id:
			return s
	return null


func _make_player_stall() -> Stall:
	var s := Stall.new()
	s.id = &"player"
	s.is_player = true
	s.aroma = player.aroma
	s.frontage = player.frontage
	s.price_level = player.price_level
	s.serve_interval_s = player.serve_interval_s
	s.avg_ticket = player.avg_ticket
	s.menu_tags = player.menu_tags
	s.visibility = pitch.visibility
	s.queue_cap = pitch.queue_cap
	s.show_burst = player.show_burst
	s.show_every_s = player.show_every_s
	s.idle_aroma_share = player.idle_aroma_share
	return s


func _make_rival_stall(r: RivalDef) -> Stall:
	var s := Stall.new()
	s.id = r.id
	s.aroma = r.aroma
	s.frontage = r.frontage
	s.price_level = r.price_level
	s.serve_interval_s = r.serve_interval_s
	s.avg_ticket = r.avg_ticket
	s.menu_tags = r.menu_tags
	s.visibility = r.visibility
	s.queue_cap = r.queue_cap
	s.show_base = r.show
	return s
