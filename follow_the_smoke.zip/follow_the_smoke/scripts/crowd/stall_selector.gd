class_name StallSelector
extends RefCounted
## Attraction and selection (GDD 5.1). Pure functions on plain data:
## no scenes, nodes, animations or UI, so it can be unit-tested and run
## headlessly on thousands of simulated customers.
##
##   U_j = wa*A + ws*H + wq*Q(n) + wf*F + wd*D - wp*P - wl*L + eps
##   Q(n) = 1 - exp(-n / QUEUE_K)                  (diminishing returns, 0-1)
##   L    = min(1, n * avg_serve / patience)        (expected wait vs patience)
##
## A, H and F are scaled by `reach` (how much of the stall's pull reaches the
## customer). Q is social proof: also scaled by reach for attraction, but not for
## selection, because once a customer has noticed a stall they can see its queue.

## Queue length at which social proof reaches ~63% of its maximum.
const QUEUE_K := 2.0


## Queue appeal, normalised to 0-1.
static func queue_appeal(queue_length: int) -> float:
	return 1.0 - exp(-float(max(queue_length, 0)) / QUEUE_K)


## Waiting penalty, normalised to 0-1.
static func wait_penalty(customer: CustomerData, stall: StallData) -> float:
	var patience: float = max(customer.type.patience_s, 0.001)
	return minf(1.0, stall.expected_wait_s() / patience)


## Share of the customer's tastes this stall's menu covers, 0-1.
## A customer with no stated tastes is indifferent (0.5).
static func menu_match(customer: CustomerData, stall: StallData) -> float:
	var tastes := customer.type.tastes
	if tastes.is_empty():
		return 0.5
	var hits := 0
	for t in tastes:
		if stall.menu_tags.has(t):
			hits += 1
	return float(hits) / float(tastes.size())


## Weighted pull the customer perceives from this stall (step 1, attraction).
static func perceived_pull(customer: CustomerData, stall: StallData) -> float:
	var t := customer.type
	var raw := t.w_aroma * stall.aroma \
		+ t.w_show * stall.show \
		+ t.w_frontage * stall.frontage \
		+ t.w_queue * queue_appeal(stall.queue_length)
	return raw * clampf(stall.reach, 0.0, 1.0)


## Utility before noise (step 2, selection).
static func calculate_utility(customer: CustomerData, stall: StallData) -> float:
	var t := customer.type
	var r := clampf(stall.reach, 0.0, 1.0)
	return t.w_aroma * stall.aroma * r \
		+ t.w_show * stall.show * r \
		+ t.w_queue * queue_appeal(stall.queue_length) \
		+ t.w_frontage * stall.frontage * r \
		+ t.w_menu * menu_match(customer, stall) \
		- t.w_price * clampf(stall.price_level, 0.0, 1.0) \
		- t.w_wait * wait_penalty(customer, stall)


static func get_attracted_stalls(customer: CustomerData, stalls: Array[StallData]) -> Array[StallData]:
	var out: Array[StallData] = []
	for s in stalls:
		if perceived_pull(customer, s) >= customer.type.notice_threshold:
			out.append(s)
	return out


## Full decision with everything the report needs.
static func select(customer: CustomerData, stalls: Array[StallData]) -> SelectionResult:
	var result := SelectionResult.new()
	result.noticed = get_attracted_stalls(customer, stalls)
	if result.noticed.is_empty():
		return result

	var base := {}
	var top := -INF
	for s in result.noticed:
		var u := calculate_utility(customer, s)
		base[s.id] = u
		top = maxf(top, u)

	var amp := customer.type.noise_fraction * absf(top)
	var best: StallData = null
	var best_u := -INF
	for s in result.noticed:
		var u: float = base[s.id] + amp * customer.noise_for(s.id)
		result.utilities[s.id] = u
		# Not viable: no room, not worth it, or they expect to give up before
		# being served (otherwise a capped wait penalty would let very long
		# queues look better than medium ones).
		if s.is_full() or u < customer.type.min_utility or wait_penalty(customer, s) >= 1.0:
			continue
		result.viable.append(s)
		if u > best_u:
			best_u = u
			best = s
	result.chosen = best
	return result


## Convenience wrapper matching the GDD sketch. null = walks past everyone.
static func select_stall(customer: CustomerData, stalls: Array[StallData]) -> StallData:
	return select(customer, stalls).chosen
