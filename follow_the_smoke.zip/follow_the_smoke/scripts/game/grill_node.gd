class_name GrillNode
extends Node2D
## The player's grill: two slots. Anything cooking gives the stall aroma, even
## with no orders, which is how a quiet stall gets its first customers.

enum Slot { EMPTY, COOKING, DONE }

const SLOTS := 2
## Extra seconds a flip adds to everything on the grill.
const FLIP_TIME_COST := 1.5
## Finished food left on the grill burns after this long (counts as waste).
const BURN_AFTER_S := 12.0

var cook_time := 8.0
var states: Array[int] = []
var timers: Array[float] = []
var burnt := 0
var _burn_flash := 0.0


func _ready() -> void:
	z_index = 2
	for i in SLOTS:
		states.append(Slot.EMPTY)
		timers.append(0.0)


func _process(delta: float) -> void:
	_burn_flash = maxf(0.0, _burn_flash - delta)
	for i in SLOTS:
		if states[i] == Slot.COOKING:
			timers[i] += delta
			if timers[i] >= cook_time:
				states[i] = Slot.DONE
				timers[i] = 0.0
		elif states[i] == Slot.DONE:
			timers[i] += delta
			if timers[i] >= BURN_AFTER_S:
				states[i] = Slot.EMPTY
				burnt += 1
				_burn_flash = 1.0
	queue_redraw()


func is_cooking() -> bool:
	return states.has(Slot.COOKING)


func count(state: int) -> int:
	return states.count(state)


## Puts one portion on an empty slot. Returns false if the grill is full.
func start_one() -> bool:
	for i in SLOTS:
		if states[i] == Slot.EMPTY:
			states[i] = Slot.COOKING
			timers[i] = 0.0
			return true
	return false


## Takes up to `max_n` finished portions off the grill.
func take_done(max_n: int) -> int:
	var taken := 0
	for i in SLOTS:
		if taken < max_n and states[i] == Slot.DONE:
			states[i] = Slot.EMPTY
			taken += 1
	return taken


## A flip makes a show burst but slows down whatever is cooking.
func flip() -> void:
	for i in SLOTS:
		if states[i] == Slot.COOKING:
			timers[i] = maxf(0.0, timers[i] - FLIP_TIME_COST)


func _draw() -> void:
	draw_rect(Rect2(-40, -16, 80, 32), Color(0.22, 0.2, 0.19))
	for i in SLOTS:
		var r := Rect2(-34 + i * 36, -10, 32, 20)
		match states[i]:
			Slot.EMPTY:
				draw_rect(r, Color(0.35, 0.3, 0.28))
			Slot.COOKING:
				var p := timers[i] / cook_time
				draw_rect(r, Color(1.0, 0.4, 0.1).lerp(Color(0.75, 0.45, 0.2), p))
				draw_rect(Rect2(r.position + Vector2(0, 22), Vector2(32 * p, 4)), Color(1, 1, 1, 0.8))
			Slot.DONE:
				var b := timers[i] / BURN_AFTER_S
				draw_rect(r, Color(0.55, 0.3, 0.15).lerp(Color(0.15, 0.1, 0.08), b))
				draw_rect(r, Color(1, 0.9, 0.5), false, 2.0)
	if _burn_flash > 0.0:
		draw_string(ThemeDB.fallback_font, Vector2(-26, -22), "burnt!", HORIZONTAL_ALIGNMENT_LEFT,
			-1, 13, Color(1, 0.4, 0.3, _burn_flash))
