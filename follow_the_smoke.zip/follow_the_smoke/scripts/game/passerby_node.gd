class_name PasserbyNode
extends Node2D
## A passer-by (or a group): walk > notice > consider > queue > leave.
## All decisions come from StallSelector; this node only moves and shows cues.

enum State { WALK, CONSIDER, TO_QUEUE, QUEUED, LEAVING }

const EVAL_INTERVAL := 0.25
const CONSIDER_TIME := 0.7
const QUEUE_SPEED := 95.0

var market  # Market
var data: CustomerData
var state := State.WALK
var dir := 1.0
var speed := 70.0
var lane_y := 450.0
var stall: StallNode = null
var queue_index := 0
var portions_needed := 1
## Outcome for the player's stall, decided when they join a queue (GDD 4).
var outcome := ""
var last_utils: Dictionary = {}

var _eval_t := 0.0
var _consider_t := 0.0
var _wait_t := 0.0
var _considered := {}
var _look_at: Vector2 = Vector2.ZERO
var _icon := ""
var _icon_t := 0.0
var _joined := false
var _color := Color.WHITE


func setup(p_market, p_data: CustomerData, p_dir: float, p_lane: float, p_speed: float) -> void:
	market = p_market
	data = p_data
	dir = p_dir
	lane_y = p_lane
	speed = p_speed
	portions_needed = data.group_size
	position = Vector2(-30.0 if dir > 0 else 1310.0, lane_y)
	_color = Color(0.45, 0.8, 0.85) if data.group_size == 1 else Color(0.95, 0.65, 0.3)
	z_index = 4


func _process(delta: float) -> void:
	_icon_t = maxf(0.0, _icon_t - delta)
	match state:
		State.WALK:
			position.x += dir * speed * delta
			_eval_t -= delta
			if _eval_t <= 0.0:
				_eval_t = EVAL_INTERVAL
				_look_for_stalls()
		State.CONSIDER:
			position.x += dir * speed * 0.3 * delta
			_consider_t -= delta
			if _consider_t <= 0.0:
				_decide()
		State.TO_QUEUE, State.QUEUED:
			var slot := stall.queue_slot(queue_index)
			position = position.move_toward(slot, QUEUE_SPEED * delta)
			state = State.QUEUED if position.distance_to(slot) < 2.0 else State.TO_QUEUE
			_wait_t += delta
			if _wait_t > data.type.patience_s:
				_abandon()
		State.LEAVING:
			if absf(position.y - lane_y) > 2.0:
				position.y = move_toward(position.y, lane_y, QUEUE_SPEED * delta)
			position.x += dir * speed * delta
	if position.x < -60.0 or position.x > 1340.0:
		if not _joined:
			market.record_outcome("walked_past_everyone")
		market.passer_left(self)
		queue_free()
	queue_redraw()


func is_at_slot() -> bool:
	return state == State.QUEUED


func _look_for_stalls() -> void:
	var snaps: Array[StallData] = market.snapshots_for(global_position)
	var best := -1.0
	var found := false
	for s in StallSelector.get_attracted_stalls(data, snaps):
		if _considered.has(s.id):
			continue
		found = true
		var p := StallSelector.perceived_pull(data, s)
		if p > best:
			best = p
			_look_at = market.stall_by_id(s.id).global_position
	if found:
		state = State.CONSIDER
		_consider_t = CONSIDER_TIME
		_show_icon("!", 0.9)


func _decide() -> void:
	var snaps: Array[StallData] = market.snapshots_for(global_position)
	var res := StallSelector.select(data, snaps)
	last_utils = res.utilities
	for s in res.noticed:
		_considered[s.id] = true
	if res.chosen == null:
		state = State.WALK
		_show_icon("...", 0.8)
		return
	var target: StallNode = market.stall_by_id(res.chosen.id)
	if not target.can_join():
		state = State.WALK
		return
	stall = target
	_joined = true
	outcome = NightSimulator._classify(res)
	if outcome == "lost_to_rival" or outcome == "went_elsewhere_uncontested":
		market.record_outcome(outcome)
	queue_index = stall.join(self)
	_wait_t = 0.0
	state = State.TO_QUEUE
	_show_icon(":)" if stall.is_player else "", 0.8)


func serve() -> void:
	if stall.is_player:
		market.record_outcome(outcome)
	stall.remove(self)
	_show_icon("$", 1.2)
	state = State.LEAVING


func _abandon() -> void:
	if stall.is_player:
		market.record_outcome("abandoned_your_queue")
	stall.remove(self)
	_show_icon(">:(", 1.5)
	state = State.LEAVING


func _show_icon(text: String, t: float) -> void:
	_icon = text
	_icon_t = t


func _draw() -> void:
	# Body: one circle per person in the group.
	var n := data.group_size
	for i in n:
		var off := Vector2((i - (n - 1) / 2.0) * 11.0, (i % 2) * 6.0)
		draw_circle(off, 8.0, _color)
	# Facing: a small dot shows where they're looking (head turns when noticing).
	var face := Vector2(dir * 9.0, -2.0)
	if state == State.CONSIDER and _look_at != Vector2.ZERO:
		face = (_look_at - global_position).normalized() * 9.0
	draw_circle(face, 3.0, Color(0.1, 0.1, 0.12))
	# Patience ring while queuing: green > yellow > red.
	if state == State.TO_QUEUE or state == State.QUEUED:
		var left := 1.0 - clampf(_wait_t / data.type.patience_s, 0.0, 1.0)
		var col := Color(0.9, 0.2, 0.2).lerp(Color(0.3, 0.9, 0.4), left)
		draw_arc(Vector2.ZERO, 13.0 + n * 2.0, -PI / 2, -PI / 2 + TAU * left, 24, col, 2.5)
		if stall.is_player and portions_needed > 1:
			draw_string(ThemeDB.fallback_font, Vector2(14, 4), "x%d" % portions_needed,
				HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1, 1, 1, 0.8))
	var font := ThemeDB.fallback_font
	if _icon_t > 0.0 and _icon != "":
		draw_string(font, Vector2(-10, -16), _icon, HORIZONTAL_ALIGNMENT_LEFT, -1, 16,
			Color(1, 1, 0.6, minf(1.0, _icon_t * 2.0)))
	# Debug: utility per stall from the last decision.
	if market.debug and not last_utils.is_empty():
		var y := 24.0
		for k in last_utils:
			draw_string(font, Vector2(-24, y), "%s %.2f" % [String(k).left(5), last_utils[k]],
				HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.8, 1, 0.8, 0.9))
			y += 11.0
