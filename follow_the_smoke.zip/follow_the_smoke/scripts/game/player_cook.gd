class_name PlayerCook
extends Node2D
## The player inside their stall. Move between the grill and the counter.
##   interact: at the grill, take finished food or start cooking;
##             at the counter, serve the customer at the front.
##   show:     flip at the grill while something cooks (burst of pull, costs time).
## With `autoplay` on, a simple bot plays (used for CI and quick checks).

const SPEED := 230.0
const REACH := 46.0
const MAX_CARRY := 4
const SHOW_BURST := 0.8
const SHOW_COOLDOWN := 1.5

var stall: StallNode
var grill: GrillNode
var market  # Market
var carrying := 0
var autoplay := false

var counter_pos := Vector2(0, -34)
var bounds := Rect2(-96, -150, 192, 122)
var _show_cd := 0.0
var _bot_cd := 0.0
var _hint := ""


func _ready() -> void:
	z_index = 2
	position = Vector2(0, -60)


func _process(delta: float) -> void:
	_show_cd = maxf(0.0, _show_cd - delta)
	# Your stall smells (and smokes) only while something is on the grill.
	stall.cooking = grill.is_cooking()
	if market.night_over_for_player():
		_hint = ""
		queue_redraw()
		return
	if autoplay:
		_bot(delta)
	else:
		var move := Input.get_vector("move_left", "move_right", "move_up", "move_down")
		position += move * SPEED * delta
		if Input.is_action_just_pressed("interact"):
			interact()
		if Input.is_action_just_pressed("show"):
			show_off()
	position = position.clamp(bounds.position, bounds.end)
	_update_hint()
	queue_redraw()


func near_grill() -> bool:
	return position.distance_to(grill.position) < REACH + 20


func near_counter() -> bool:
	return position.distance_to(counter_pos) < REACH


func interact() -> void:
	if near_grill():
		var got := grill.take_done(MAX_CARRY - carrying)
		carrying += got
		if got == 0 and grill.start_one():
			market.record_cost(market.INGREDIENT_COST)
	elif near_counter() and carrying > 0:
		var h = stall.head()
		if h != null and h.is_at_slot():
			var give: int = mini(carrying, h.portions_needed)
			carrying -= give
			h.portions_needed -= give
			if h.portions_needed <= 0:
				market.record_sale(stall, stall.ticket * h.data.group_size)
				market.note_player_serve()
				h.serve()


func show_off() -> void:
	if near_grill() and grill.is_cooking() and _show_cd <= 0.0:
		grill.flip()
		stall.trigger_show(SHOW_BURST)
		_show_cd = SHOW_COOLDOWN


func _update_hint() -> void:
	if near_grill():
		if grill.count(GrillNode.Slot.DONE) > 0 and carrying < MAX_CARRY:
			_hint = "E: take food"
		elif grill.count(GrillNode.Slot.EMPTY) > 0:
			_hint = "E: cook ($%d)" % market.INGREDIENT_COST
		else:
			_hint = ""
		if grill.is_cooking():
			_hint += "   Space: flip!" if _show_cd <= 0.0 else ""
	elif near_counter():
		var h = stall.head()
		if carrying > 0 and h != null and h.is_at_slot():
			_hint = "E: serve"
		elif carrying == 0 and h != null:
			_hint = "No food: go to the grill"
		else:
			_hint = ""
	else:
		_hint = ""


## Simple bot: keep the grill busy, carry food to the counter, flip when the
## queue is short (to pull people in), never when it's long.
func _bot(delta: float) -> void:
	_bot_cd = maxf(0.0, _bot_cd - delta)
	var h = stall.head()
	var waiting := 0
	for p in stall.queue:
		waiting += p.portions_needed
	var target: Vector2
	if carrying > 0 and h != null and h.is_at_slot():
		target = counter_pos
	elif grill.count(GrillNode.Slot.DONE) > 0 and carrying < MAX_CARRY:
		target = grill.position + Vector2(0, 30)
	elif grill.count(GrillNode.Slot.EMPTY) > 0 and carrying + grill.count(GrillNode.Slot.COOKING) < maxi(1, waiting):
		target = grill.position + Vector2(0, 30)
	elif grill.count(GrillNode.Slot.COOKING) == 0 and grill.count(GrillNode.Slot.EMPTY) > 0:
		target = grill.position + Vector2(0, 30)  # keep the grill hot to draw people
	else:
		target = counter_pos
	var to := target - position
	if to.length() > 8.0:
		position += to.normalized() * minf(SPEED * delta, to.length())
	if _bot_cd <= 0.0:
		if near_grill() and stall.queue.size() <= 2:
			show_off()
		if position.distance_to(target) < 10.0:
			interact()
			_bot_cd = 0.25


func _draw() -> void:
	draw_circle(Vector2.ZERO, 14, Color(0.95, 0.95, 0.98))
	draw_rect(Rect2(-9, 2, 18, 12), Color(0.9, 0.3, 0.3))
	for i in carrying:
		draw_circle(Vector2(-12 + i * 8, -22), 4, Color(0.6, 0.33, 0.15))
	if _hint != "":
		var font := ThemeDB.fallback_font
		draw_string(font, Vector2(-60, 34), _hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1, 1, 0.8))
