class_name RivalController
extends Node
## Cheap rival (GDD 5.2): fixed pull profile, a serving interval, a queue and
## simple animations. No cooking, inventory or ingredient simulation.

var stall: StallNode
var market  # Market, for stats
var _serve_t := 0.0


func _process(delta: float) -> void:
	var h = stall.head()
	# Established rivals always have something on the grill (fixed pull profile),
	# so the market never starts dead.
	stall.cooking = true
	if h == null or not h.is_at_slot():
		_serve_t = 0.0
		return
	_serve_t += delta
	var need: float = stall.avg_serve_s * (1.0 + 0.3 * (h.data.group_size - 1))
	if _serve_t >= need:
		_serve_t = 0.0
		var pay: int = stall.ticket * h.data.group_size
		market.record_sale(stall, pay)
		h.serve()
