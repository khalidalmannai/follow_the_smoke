class_name StallNode
extends Node2D
## One stall in the aisle. The SAME script is used for the player's stall and
## for rivals (GDD 9), so selection, queues and patience treat them alike.
## A controller (PlayerCook or RivalController) sets `cooking` and serves.
## Node position = centre of the stall's front edge, where the queue starts.

## Pull is at full strength within NEAR_RADIUS (px) of the counter and fades
## to nothing at PULL_RADIUS. The aisle's lanes sit 100-320 px from the counter.
const NEAR_RADIUS := 200.0
const PULL_RADIUS := 520.0
const WIDTH := 220.0
const DEPTH := 170.0
const QUEUE_SPACING := 30.0
## A show burst fades from full to zero in this many seconds.
const SHOW_DECAY_S := 3.0

var id: StringName
var display_name := ""
var is_player := false
var color := Color(0.85, 0.55, 0.3)

## Pull inputs (0-1).
var aroma_strength := 0.5
var idle_aroma_share := 0.25
var frontage := 0.3
var show_base := 0.0
var show_level := 0.0
var price_level := 0.5
var visibility := 0.8
var menu_tags := PackedStringArray()

var avg_serve_s := 12.0
var queue_cap := 8
## Money per portion (player) or per person (rivals).
var ticket := 6

## True while food is actively cooking: drives aroma and smoke.
var cooking := false
var queue: Array = []  # of PasserbyNode, front first
var vendor_bob := 0.0
## Where the grill/smoke sits, relative to the stall's front edge.
var grill_offset := Vector2(0, -100)

var _smoke: CPUParticles2D
var _flash := 0.0


func _ready() -> void:
	z_index = 1
	_smoke = CPUParticles2D.new()
	_smoke.position = grill_offset
	_smoke.amount = int(6 + 30 * aroma_strength)
	_smoke.lifetime = 4.0
	_smoke.direction = Vector2(0, 1)
	_smoke.spread = 35.0
	_smoke.gravity = Vector2(0, 12)
	_smoke.initial_velocity_min = 45.0
	_smoke.initial_velocity_max = 75.0
	_smoke.scale_amount_min = 6.0
	_smoke.scale_amount_max = 14.0
	var ramp := Gradient.new()
	ramp.set_color(0, Color(0.85, 0.85, 0.85, 0.55))
	ramp.set_color(1, Color(0.6, 0.6, 0.65, 0.0))
	_smoke.color_ramp = ramp
	_smoke.emitting = false
	_smoke.z_index = 3
	add_child(_smoke)


func _process(delta: float) -> void:
	show_level = maxf(0.0, show_level - delta / SHOW_DECAY_S)
	_flash = maxf(0.0, _flash - delta * 2.0)
	if cooking:
		vendor_bob += delta * 8.0
	_smoke.emitting = cooking
	queue_redraw()


func current_aroma() -> float:
	return aroma_strength if cooking else aroma_strength * idle_aroma_share


func current_show() -> float:
	return maxf(show_level, show_base)


func trigger_show(amount: float) -> void:
	show_level = maxf(show_level, amount)
	_flash = 1.0


## How much of this stall's pull reaches a point (distance falloff x visibility).
func reach_at(pos: Vector2) -> float:
	var d := pos.distance_to(global_position)
	var fade := 1.0 - (d - NEAR_RADIUS) / (PULL_RADIUS - NEAR_RADIUS)
	return visibility * clampf(fade, 0.0, 1.0)


func snapshot_for(pos: Vector2) -> StallData:
	var s := StallData.new()
	s.id = id
	s.is_player = is_player
	s.aroma = current_aroma()
	s.show = current_show()
	s.frontage = frontage
	s.queue_length = queue.size()
	s.queue_cap = queue_cap
	s.avg_serve_s = avg_serve_s
	s.price_level = price_level
	s.menu_tags = menu_tags
	s.reach = reach_at(pos)
	return s


func queue_slot(i: int) -> Vector2:
	# Line runs down from the counter, then bends sideways if it gets long.
	var down := mini(i, 5)
	var side := maxi(0, i - 5)
	return global_position + Vector2(side * QUEUE_SPACING * (1 if is_player else -1),
		22.0 + down * QUEUE_SPACING)


func can_join() -> bool:
	return queue.size() < queue_cap


func join(p) -> int:
	queue.append(p)
	return queue.size() - 1


func remove(p) -> void:
	queue.erase(p)
	for i in queue.size():
		queue[i].queue_index = i


func head():
	return null if queue.is_empty() else queue[0]


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var body := Rect2(-WIDTH / 2, -DEPTH, WIDTH, DEPTH - 18)
	# Back wall and floor of the stall.
	draw_rect(body, color.darkened(0.72))
	draw_rect(body, color.darkened(0.3), false, 2.0)
	# Awning stripes.
	for i in 11:
		var c := color if i % 2 == 0 else color.lightened(0.35)
		draw_rect(Rect2(-WIDTH / 2 + i * WIDTH / 11.0, -DEPTH - 16, WIDTH / 11.0 + 0.5, 16), c)
	# Frontage: lanterns along the awning (more frontage = more lanterns).
	var lanterns := int(round(frontage * 8))
	for i in lanterns:
		var x := -WIDTH / 2 + 14 + i * ((WIDTH - 28) / maxf(1, lanterns - 1))
		draw_circle(Vector2(x, -DEPTH + 6), 6, Color(1.0, 0.75, 0.3))
	# Counter.
	draw_rect(Rect2(-WIDTH / 2, -18, WIDTH, 18), color.darkened(0.15))
	# Name sign.
	var name_w := font.get_string_size(display_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x
	draw_string(font, Vector2(-name_w / 2, -DEPTH - 24), display_name,
		HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1, 0.95, 0.85))
	# Rival vendor (the player draws themself).
	if not is_player:
		var bob := sin(vendor_bob) * 3.0 if cooking else 0.0
		draw_circle(grill_offset + Vector2(0, 40 + bob), 13, Color(0.9, 0.8, 0.7))
		draw_rect(Rect2(grill_offset + Vector2(-26, -8), Vector2(52, 16)), Color(0.25, 0.22, 0.2))
		if cooking:
			draw_rect(Rect2(grill_offset + Vector2(-20, -5), Vector2(40, 10)),
				Color(1.0, 0.45, 0.1, 0.6 + 0.4 * sin(vendor_bob * 1.7)))
	# Show flash.
	if _flash > 0.0:
		draw_circle(grill_offset, 30 + 40 * (1.0 - _flash), Color(1.0, 0.6, 0.15, 0.5 * _flash))
