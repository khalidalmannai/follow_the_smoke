class_name Market
extends Node2D
## The week 1-2 crowd-pull experiment (GDD 11): one aisle, three stalls (you in
## the middle, two rivals), passers-by choosing with StallSelector, queues with
## patience, a grill with smoke, a flip, a debug view and a night report.
##
## Command-line options (after `--`):
##   --autoplay           a bot plays your stall
##   --fast               run 8x speed
##   --night=180          night length in seconds
##   --seed=N             fixed seed (same seed = same crowd)
##   --quit-after-report  print the report and quit (used by CI)
##   --shot=PATH --shot-at=SECONDS  save a screenshot (with --debug-view: debug on)

const SCREEN := Vector2(1280, 720)
const START_MONEY := 100
const INGREDIENT_COST := 3
const CLOSING_GRACE_S := 30.0
const OUTCOME_KEYS := ["won_from_rival", "won_uncontested", "lost_to_rival",
	"walked_past_everyone", "abandoned_your_queue", "went_elsewhere_uncontested"]

var debug := false
var night_length := 180.0
var night_t := 0.0
var money := START_MONEY
var outcomes := {}
var revenue := {}
var costs := 0
var passers_spawned := 0

var stalls: Array = []  # of StallNode
var player_stall: StallNode
var player: PlayerCook
var grill: GrillNode
var pitch: PitchDef

var _types: Array = []
var _type_weight := 0.0
var _rng := RandomNumberGenerator.new()
var _seed := 0
var _passers: Array = []
var _report_shown := false
var _closing_t := 0.0
var _last_serve_t := -1.0
var _quit_after_report := false
var _autoplay := false
var _shot_path := ""
var _shot_at := -1.0

var _hud: Label
var _help: Label
var _debug_label: Label
var _report: PanelContainer
var _report_text: Label


func _ready() -> void:
	_setup_input()
	var args := _args()
	_autoplay = args.has("autoplay")
	_quit_after_report = args.has("quit-after-report")
	if args.has("fast"):
		Engine.time_scale = 8.0
	night_length = float(args.get("night", "180"))
	_seed = int(args["seed"]) if args.has("seed") else int(Time.get_unix_time_from_system())
	_rng.seed = _seed
	debug = args.has("debug-view")
	if args.has("shot"):
		_shot_path = args["shot"]
		_shot_at = float(args.get("shot-at", "30"))

	for k in OUTCOME_KEYS:
		outcomes[k] = 0

	# Content comes from the DataManager autoload; load directly if it isn't
	# running (e.g. when a tool script instantiates this scene).
	var dm := get_node_or_null("/root/DataManager")
	if dm and dm.pitches.is_empty():
		dm.reload()
	var pitches: Dictionary = dm.pitches if dm else DefLoader.load_by_id("res://data/pitches")
	var customers: Dictionary = dm.customers if dm else DefLoader.load_by_id("res://data/customers")
	var rivals: Dictionary = dm.rivals if dm else DefLoader.load_by_id("res://data/rivals")
	var recipes: Dictionary = dm.recipes if dm else DefLoader.load_by_id("res://data/recipes")
	pitch = pitches[&"busy_aisle"]
	_types = customers.values()
	for t in _types:
		_type_weight += t.spawn_weight

	_build_player_stall(recipes[&"grilled_skewers"])
	_build_rival(rivals[&"drinks_cart"], 300.0, Color(0.35, 0.6, 0.9))
	_build_rival(rivals[&"grill_master"], 980.0, Color(0.75, 0.4, 0.75))
	for s in stalls:
		revenue[s.id] = 0
	_build_hud()


# --- building --------------------------------------------------------------

func _build_player_stall(recipe: RecipeDef) -> void:
	var s := StallNode.new()
	s.id = &"player"
	s.display_name = "YOUR STALL - " + recipe.display_name
	s.is_player = true
	s.color = Color(0.95, 0.45, 0.25)
	s.aroma_strength = recipe.aroma_strength
	s.idle_aroma_share = 0.15
	s.frontage = 0.3
	s.price_level = 0.5
	s.ticket = recipe.price
	s.menu_tags = recipe.cuisine_tags
	s.visibility = pitch.visibility
	s.queue_cap = pitch.queue_cap
	s.avg_serve_s = 12.0
	s.grill_offset = Vector2(-60, -100)
	s.position = Vector2(640, 290)
	add_child(s)
	stalls.append(s)
	player_stall = s

	grill = GrillNode.new()
	grill.cook_time = recipe.cook_time_s
	grill.position = s.grill_offset
	s.add_child(grill)

	player = PlayerCook.new()
	player.stall = s
	player.grill = grill
	player.market = self
	player.autoplay = _autoplay
	s.add_child(player)


func _build_rival(def: RivalDef, x: float, color: Color) -> void:
	var s := StallNode.new()
	s.id = def.id
	s.display_name = def.display_name
	s.color = color
	s.aroma_strength = def.aroma
	s.idle_aroma_share = NightSimulator.IDLE_AROMA_SHARE
	s.show_base = def.show
	s.frontage = def.frontage
	s.price_level = def.price_level
	s.avg_serve_s = def.serve_interval_s
	s.ticket = def.avg_ticket
	s.menu_tags = def.menu_tags
	s.visibility = def.visibility
	s.queue_cap = def.queue_cap
	s.position = Vector2(x, 290)
	add_child(s)
	stalls.append(s)
	var c := RivalController.new()
	c.stall = s
	c.market = self
	s.add_child(c)


func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	_hud = Label.new()
	_hud.position = Vector2(16, 10)
	_hud.add_theme_font_size_override("font_size", 18)
	layer.add_child(_hud)
	_help = Label.new()
	_help.position = Vector2(16, SCREEN.y - 28)
	_help.add_theme_font_size_override("font_size", 14)
	_help.modulate = Color(1, 1, 1, 0.75)
	_help.text = "Move: WASD / arrows / stick    E / Enter / (A): cook, take, serve    " \
		+ "Space / (X): flip    F1: debug    R: new night"
	layer.add_child(_help)
	_debug_label = Label.new()
	_debug_label.position = Vector2(SCREEN.x - 400, 632)
	_debug_label.add_theme_font_size_override("font_size", 11)
	_debug_label.visible = debug
	var dbg_style := StyleBoxFlat.new()
	dbg_style.bg_color = Color(0, 0, 0, 0.7)
	dbg_style.set_content_margin_all(6)
	_debug_label.add_theme_stylebox_override("normal", dbg_style)
	layer.add_child(_debug_label)

	_report = PanelContainer.new()
	_report.position = Vector2(390, 120)
	_report.custom_minimum_size = Vector2(500, 0)
	_report.visible = false
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.08, 0.07, 0.12, 0.94)
	style.border_color = Color(1.0, 0.7, 0.3)
	style.set_border_width_all(2)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(18)
	_report.add_theme_stylebox_override("panel", style)
	_report_text = Label.new()
	_report_text.add_theme_font_size_override("font_size", 16)
	_report.add_child(_report_text)
	layer.add_child(_report)


# --- loop ------------------------------------------------------------------

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("toggle_debug"):
		debug = not debug
		_debug_label.visible = debug
	if Input.is_action_just_pressed("restart"):
		Engine.time_scale = 1.0 if not _args().has("fast") else 8.0
		get_tree().reload_current_scene()
		return

	if not _report_shown:
		night_t += delta
		if night_t < night_length:
			_maybe_spawn(delta)
		else:
			_closing_t += delta
			if _queues_empty() or _closing_t > CLOSING_GRACE_S:
				_show_report()
	_update_hud()
	queue_redraw()
	if _shot_path != "" and night_t >= _shot_at:
		var img := get_viewport().get_texture().get_image()
		img.save_png(_shot_path)
		print("screenshot saved: ", _shot_path)
		_shot_path = ""


func _maybe_spawn(delta: float) -> void:
	if _rng.randf() >= pitch.traffic_per_min / 60.0 * delta:
		return
	var t: CustomerTypeDef = _pick_type()
	var c := CustomerData.create(t, _rng.randi(), _rng.randi_range(t.group_size_min, t.group_size_max))
	var p := PasserbyNode.new()
	var dir := 1.0 if _rng.randf() < 0.5 else -1.0
	p.setup(self, c, dir, _rng.randf_range(390.0, 610.0), _rng.randf_range(58.0, 85.0))
	add_child(p)
	_passers.append(p)
	passers_spawned += 1


func _pick_type() -> CustomerTypeDef:
	var roll := _rng.randf() * _type_weight
	for t in _types:
		roll -= t.spawn_weight
		if roll <= 0.0:
			return t
	return _types[-1]


func _queues_empty() -> bool:
	for s in stalls:
		if not s.queue.is_empty():
			return false
	return true


# --- used by stalls, passers-by and the player -----------------------------

func snapshots_for(pos: Vector2) -> Array[StallData]:
	var out: Array[StallData] = []
	for s in stalls:
		out.append(s.snapshot_for(pos))
	return out


func stall_by_id(id: StringName) -> StallNode:
	for s in stalls:
		if s.id == id:
			return s
	return null


func record_outcome(key: String) -> void:
	if _report_shown:
		return
	outcomes[key] = outcomes.get(key, 0) + 1


func record_sale(stall: StallNode, amount: int) -> void:
	revenue[stall.id] = revenue.get(stall.id, 0) + amount
	if stall.is_player:
		money += amount


func record_cost(amount: int) -> void:
	money -= amount
	costs += amount


## Keeps the player's average serving time realistic for the wait penalty.
func note_player_serve() -> void:
	if _last_serve_t >= 0.0:
		var gap := clampf(night_t - _last_serve_t, 3.0, 30.0)
		player_stall.avg_serve_s = lerpf(player_stall.avg_serve_s, gap, 0.3)
	_last_serve_t = night_t


func passer_left(p) -> void:
	_passers.erase(p)


func night_over_for_player() -> bool:
	return _report_shown


# --- HUD, report, drawing --------------------------------------------------

func _update_hud() -> void:
	var left := maxf(0.0, night_length - night_t)
	var clock := "%d:%02d" % [int(left) / 60, int(left) % 60] if left > 0.0 else "CLOSING"
	var won: int = outcomes["won_from_rival"] + outcomes["won_uncontested"]
	_hud.text = "Time %s    Money $%d    Carrying %d    Your queue %d    Served %d" % [
		clock, money, player.carrying, player_stall.queue.size(), won]
	if debug:
		var lines := PackedStringArray()
		for s in stalls:
			lines.append("%-12s A %.2f H %.2f F %.2f Q %d serve %.0fs" % [
				String(s.id).left(12), s.current_aroma(), s.current_show(), s.frontage,
				s.queue.size(), s.avg_serve_s])
		lines.append("won rival %d | won free %d | lost %d | walked %d | abandoned %d | seed %d" % [
			outcomes["won_from_rival"], outcomes["won_uncontested"], outcomes["lost_to_rival"],
			outcomes["walked_past_everyone"], outcomes["abandoned_your_queue"], _seed])
		_debug_label.text = "\n".join(lines)


func _show_report() -> void:
	_report_shown = true
	var wasted := grill.burnt + player.carrying + grill.count(GrillNode.Slot.DONE) \
		+ grill.count(GrillNode.Slot.COOKING)
	var still_queuing := player_stall.queue.size()
	var lines := PackedStringArray()
	lines.append("NIGHT REPORT")
	lines.append("")
	lines.append("Crowd (%d passers-by)" % passers_spawned)
	lines.append("  Won from a rival            %d" % outcomes["won_from_rival"])
	lines.append("  Won uncontested             %d" % outcomes["won_uncontested"])
	lines.append("  Lost to a rival             %d" % outcomes["lost_to_rival"])
	lines.append("  Walked past everyone        %d" % outcomes["walked_past_everyone"])
	lines.append("  Abandoned your queue        %d" % outcomes["abandoned_your_queue"])
	lines.append("  (went to a rival, never considered you: %d)" % outcomes["went_elsewhere_uncontested"])
	if still_queuing > 0:
		lines.append("  (still queuing at closing: %d)" % still_queuing)
	lines.append("")
	lines.append("Money")
	lines.append("  Sales $%d   Ingredients -$%d   Rent -$%d" % [revenue[&"player"], costs, pitch.rent_per_night])
	lines.append("  Net for the night: $%d   (portions wasted: %d)" % [
		revenue[&"player"] - costs - pitch.rent_per_night, wasted])
	lines.append("  Rivals: drinks cart $%d, grill $%d" % [revenue[&"drinks_cart"], revenue[&"grill_master"]])
	lines.append("")
	lines.append("R / Start: play another night")
	_report_text.text = "\n".join(lines)
	_report.visible = true
	print("\n".join(lines))
	print("seed=%d autoplay=%s" % [_seed, str(_autoplay)])
	if _quit_after_report:
		get_tree().quit(0)


func _draw() -> void:
	# Night sky / back of the market.
	draw_rect(Rect2(Vector2.ZERO, SCREEN), Color(0.07, 0.06, 0.12))
	# Aisle floor.
	draw_rect(Rect2(0, 300, SCREEN.x, 330), Color(0.16, 0.14, 0.2))
	for i in 33:
		draw_rect(Rect2(i * 40, 300, 20, 330), Color(0.18, 0.16, 0.22))
	# String lights over the aisle.
	for i in 40:
		var x := i * 33.0 + 8.0
		var y := 64.0 + sin(i * 0.9) * 6.0
		draw_circle(Vector2(x, y), 3.0, Color(1.0, 0.8, 0.4, 0.7))
	# Debug: pull rings: full strength inside the inner ring, zero at the outer.
	if debug:
		for s in stalls:
			var c: Vector2 = s.global_position
			draw_arc(c, StallNode.NEAR_RADIUS, 0, TAU, 64, Color(s.color, 0.5), 1.5)
			draw_arc(c, StallNode.PULL_RADIUS, 0, TAU, 96, Color(s.color, 0.25), 1.0)


# --- input & args ----------------------------------------------------------

func _setup_input() -> void:
	var keys := {
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"move_up": [KEY_W, KEY_UP], "move_down": [KEY_S, KEY_DOWN],
		"interact": [KEY_E, KEY_ENTER], "show": [KEY_SPACE],
		"toggle_debug": [KEY_F1], "restart": [KEY_R],
	}
	var pads := {"interact": JOY_BUTTON_A, "show": JOY_BUTTON_X, "restart": JOY_BUTTON_START}
	var axes := {
		"move_left": [JOY_AXIS_LEFT_X, -1.0], "move_right": [JOY_AXIS_LEFT_X, 1.0],
		"move_up": [JOY_AXIS_LEFT_Y, -1.0], "move_down": [JOY_AXIS_LEFT_Y, 1.0],
	}
	var dpad := {"move_left": JOY_BUTTON_DPAD_LEFT, "move_right": JOY_BUTTON_DPAD_RIGHT,
		"move_up": JOY_BUTTON_DPAD_UP, "move_down": JOY_BUTTON_DPAD_DOWN}
	for action in keys:
		if InputMap.has_action(action):
			continue
		InputMap.add_action(action, 0.25)
		for k in keys[action]:
			var e := InputEventKey.new()
			e.physical_keycode = k
			InputMap.action_add_event(action, e)
		if pads.has(action):
			var b := InputEventJoypadButton.new()
			b.button_index = pads[action]
			InputMap.action_add_event(action, b)
		if dpad.has(action):
			var d := InputEventJoypadButton.new()
			d.button_index = dpad[action]
			InputMap.action_add_event(action, d)
		if axes.has(action):
			var m := InputEventJoypadMotion.new()
			m.axis = axes[action][0]
			m.axis_value = axes[action][1]
			InputMap.action_add_event(action, m)


func _args() -> Dictionary:
	var out := {}
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--"):
			var kv := a.substr(2).split("=", true, 1)
			out[kv[0]] = kv[1] if kv.size() > 1 else "true"
	return out
