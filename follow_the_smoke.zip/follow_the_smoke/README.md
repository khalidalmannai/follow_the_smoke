# Follow the Smoke: weeks 1-2 foundation

Godot 4.4 project, built from GDD v1.1. This is the crowd-pull core, without graphics:
the data, the selection logic and a headless simulator for tuning it.

## What's here

```
data/
  customers/   stroller.tres, worker_group.tres     CustomerTypeDef (weights, patience, tastes)
  pitches/     quiet_corner.tres, busy_aisle.tres   PitchDef (traffic, rent, visibility, queue cap)
  rivals/      drinks_cart.tres, grill_master.tres  RivalDef (fixed pull, serving interval)
  recipes/     grilled_skewers, street_noodles, iced_drink   RecipeDef (aroma vs speed)
scripts/
  data/        the Def resource classes
  crowd/
    stall_selector.gd    attraction + selection, pure functions (GDD 5.1)
    customer_data.gd     plain-data passer-by snapshot (seeded noise)
    stall_data.gd        plain-data stall snapshot, same shape for player and rivals
    selection_result.gd  what was noticed, what was viable, what was chosen
    night_simulator.gd   deterministic headless night: arrivals, queues, serving, patience
  core/
    data_manager.gd      autoload: loads all Defs at startup
    def_loader.gd        static loader, also used by the headless tools
tools/
  crowd_sim.gd           command-line tuning tool
  test_stall_selector.gd unit tests
scenes/                  empty folders for the week 1-2 scenes
```

Every number in `data/` is a starting guess for tuning, not a balanced value.
Open any `.tres` in the Godot inspector to edit it with sliders.

## Run it

First time only, so Godot registers the classes: open the project in the editor once, or run
`godot --headless --import` in the project folder.

```
# unit tests (exit code 0 = pass)
godot --headless -s res://tools/test_stall_selector.gd

# simulate 5 nights on the busy pitch
godot --headless -s res://tools/crowd_sim.gd

# compare using show actions vs not, and print the queue curve
godot --headless -s res://tools/crowd_sim.gd -- --compare --curve

# try settings: options are listed at the top of tools/crowd_sim.gd
godot --headless -s res://tools/crowd_sim.gd -- --pitch=quiet_corner --aroma=0.9 --keep-grill-hot
```

On Windows, use the console executable (`Godot_v4.x-stable_win64_console.exe`) in place of
`godot`, so the results print to the terminal.

The report uses the GDD's five crowd outcomes, plus `went_elsewhere_uncontested`: customers
who went to a rival without ever considering you. The same seed always gives the same night.

## Changes from the GDD found by the simulator

1. **Customers don't join a queue they expect to give up on.** If expected wait is at least
   their patience, the stall isn't a real option for them. Without this rule, the wait
   penalty stops growing at its cap of 1 while queue appeal keeps rising, so very long
   queues scored better than medium ones. Queue abandonment fell from about 18 to about 1
   per night.
2. **Cold start.** A stall with an empty queue isn't cooking, so its aroma drops to 40%
   and a quiet pitch can't get noticed at all (0 customers). Keeping the grill going
   (`--keep-grill-hot`) fixes it in the simulator (0 to about 109 revenue a night). The game
   needs an answer: cooking with no orders to attract people, which wastes ingredients, is
   the obvious candidate, and it fits pillar 1.
3. **Show actions currently cost more than they earn on a busy pitch.** They help draw a
   crowd but slow down serving. That trade-off is intended, but the burst size versus
   time cost needs tuning so showing off pays when the queue is short.

## Next (rest of weeks 1-2)

- `scenes/market/market.tscn`: aisle, three stall positions, CrowdSpawner, player movement.
- `scenes/stalls/stall.tscn`: one scene, player or rival controller, with pull emitters
  feeding a `StallData` snapshot each time a passer-by evaluates it.
- `scenes/customers/passerby.tscn`: state machine walk > notice > choose > queue > leave,
  calling `StallSelector.select()`. `reach` = distance falloff x pitch visibility.
- Debug overlay: pull radii and each passer-by's U scores.
