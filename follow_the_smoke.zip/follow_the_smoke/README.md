# Follow the Smoke: crowd-pull experiment (weeks 1-2)

Godot 4.4 project, built from GDD v1.1: a playable version of the week 2 crowd-pull
experiment with placeholder shapes, plus the selection logic, unit tests and a headless
simulator for tuning.

![The crowd-pull experiment](docs/screenshot.png)

## Play it

1. Install [Godot 4.4](https://godotengine.org/download) (the standard version, not .NET).
2. Unzip the project, open Godot, click **Import**, and select `project.godot`.
3. Press **F5** (or the Play button). Each night lasts 3 minutes.

| Action | Keyboard | Controller |
| --- | --- | --- |
| Move around your stall | WASD / arrows | Left stick / D-pad |
| At the grill: take finished food, or start cooking ($3) | E / Enter | A |
| At the counter: serve the customer at the front | E / Enter | A |
| Flip while something cooks: burst of pull, costs 1.5 s | Space | X |
| Debug view: pull rings, every passer-by's scores | F1 | |
| New night | R | Start |

How it works: food on the grill gives off smoke and aroma, which draws passers-by.
When they notice a stall they turn their head ("!"), slow down, and pick one. Their
patience ring empties while they queue. Groups (orange) need one portion per person.
Food left on the grill burns after 12 seconds. The night report shows the five crowd
outcomes from the GDD.

**What to test (GDD section 11):** give it to someone who has never seen it and don't
explain the mechanic. Can they say why customers came to them? Do they cook or flip to
draw people in, not just to fill orders? Do they ask to play another night?

Command-line options: `--autoplay` (a bot plays your stall), `--fast` (8x speed),
`--seed=N`, `--night=SECONDS`, `--debug-view`, `--quit-after-report`,
`--shot=file.png --shot-at=SECONDS` (screenshot).

## What's here

```
data/
  customers/   stroller.tres, worker_group.tres     CustomerTypeDef (weights, patience, tastes)
  pitches/     quiet_corner.tres, busy_aisle.tres   PitchDef (traffic, rent, visibility, queue cap)
  rivals/      drinks_cart.tres, grill_master.tres  RivalDef (fixed pull, serving interval)
  recipes/     grilled_skewers, street_noodles, iced_drink   RecipeDef (aroma vs speed)
scripts/
  data/        the Def resource classes
  crowd/
    stall_selector.gd    attraction + selection, pure functions (GDD 5.1)
    customer_data.gd     plain-data passer-by snapshot (seeded noise)
    stall_data.gd        plain-data stall snapshot, same shape for player and rivals
    selection_result.gd  what was noticed, what was viable, what was chosen
    night_simulator.gd   deterministic headless night: arrivals, queues, serving, patience
  core/
    data_manager.gd      autoload: loads all Defs at startup
    def_loader.gd        static loader, also used by the headless tools
tools/
  crowd_sim.gd           command-line tuning tool
  test_stall_selector.gd unit tests
  game/
    market.gd            the scene: spawning, stats, HUD, report, input, debug view
    stall_node.gd        ONE stall script for player and rivals (pull, queue, smoke)
    rival_controller.gd  cheap rival: always cooking, fixed serving interval
    grill_node.gd        your grill: 2 slots, cooking, burning
    player_cook.gd       you: move, cook, serve, flip (+ autoplay bot)
    passerby_node.gd     walk > notice > consider > queue > leave, using StallSelector
scenes/main/main.tscn    the main scene
```

Every number in `data/` is a starting guess for tuning, not a balanced value.
Open any `.tres` in the Godot inspector to edit it with sliders.

## Run it

First time only, so Godot registers the classes: open the project in the editor once, or run
`godot --headless --import` in the project folder.

```
# unit tests (exit code 0 = pass)
godot --headless -s res://tools/test_stall_selector.gd

# simulate 5 nights on the busy pitch
godot --headless -s res://tools/crowd_sim.gd

# compare using show actions vs not, and print the queue curve
godot --headless -s res://tools/crowd_sim.gd -- --compare --curve

# try settings: options are listed at the top of tools/crowd_sim.gd
godot --headless -s res://tools/crowd_sim.gd -- --pitch=quiet_corner --aroma=0.9 --keep-grill-hot
```

On Windows, use the console executable (`Godot_v4.x-stable_win64_console.exe`) in place of
`godot`, so the results print to the terminal.

The report uses the GDD's five crowd outcomes, plus `went_elsewhere_uncontested`: customers
who went to a rival without ever considering you. The same seed always gives the same night.

## Changes from the GDD found by the simulator

1. **Customers don't join a queue they expect to give up on.** If expected wait is at least
   their patience, the stall isn't a real option for them. Without this rule, the wait
   penalty stops growing at its cap of 1 while queue appeal keeps rising, so very long
   queues scored better than medium ones. Queue abandonment fell from about 18 to about 1
   per night.
2. **Cold start.** A stall with an empty queue isn't cooking, so its aroma drops to 40%
   and a quiet pitch can't get noticed at all (0 customers). Keeping the grill going
   (`--keep-grill-hot`) fixes it in the simulator (0 to about 109 revenue a night). The game
   needs an answer: cooking with no orders to attract people, which wastes ingredients, is
   the obvious candidate, and it fits pillar 1.
3. **Show actions currently cost more than they earn on a busy pitch.** They help draw a
   crowd but slow down serving. That trade-off is intended, but the burst size versus
   time cost needs tuning so showing off pays when the queue is short.

4. **Pull needs a near zone (playable scene).** Pull is at full strength within 200 px of
   a counter, and fades to zero at 520 px. Fading from the counter itself made every
   stall too weak to notice from the aisle.
5. **Rivals always have food on the grill.** If idle rivals lose their aroma, nobody
   notices any stall at the start of a night and the market never gets going. This fits
   GDD 5.2's fixed pull profile.
6. **Food burns after 12 s on the grill.** Keeping the grill going to draw a crowd now
   has a real cost: wasted ingredients. This is the cold-start answer from item 2.

## Next

- Run the outside playtest (5-10 people) and fill in the GDD section 11 checklist.
- Tune with the debug view (F1) and the simulator until the hook passes.
- Week 3: the three recipes, a proper prep step, better smoke and head-turn cues.
- Week 4: pitch choice, lantern upgrade, the five-night run.
