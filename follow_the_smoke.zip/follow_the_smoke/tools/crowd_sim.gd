extends SceneTree
## Headless crowd simulator for tuning (GDD 9: deterministic nights).
##
## Usage (from the project folder):
##   godot --headless -s res://tools/crowd_sim.gd -- [options]
##
## Options (all optional):
##   --nights=5            nights to simulate (seeds seed, seed+1, ...)
##   --seed=1              base seed; same seed = same result
##   --pitch=busy_aisle    id of a PitchDef in data/pitches
##   --aroma=0.7           player aroma while cooking (0-1)
##   --frontage=0.3        player frontage (0-1)
##   --price=0.5           player price level (0 cheap - 1 expensive)
##   --serve=12            player seconds per customer
##   --show-every=0        seconds between show actions (0 = never)
##   --show-burst=0.8      pull of one show action (0-1)
##   --keep-grill-hot      keep full aroma with an empty queue (cold-start test)
##   --compare             also run with show actions every 15 s, side by side
##   --curve               print the queue's net effect per customer type


func _init() -> void:
	var args := _parse_args(OS.get_cmdline_user_args())
	var types: Array = DefLoader.load_dir("res://data/customers")
	var pitches := DefLoader.load_by_id("res://data/pitches")
	var rivals: Array = DefLoader.load_dir("res://data/rivals")

	var pitch_id := StringName(args.get("pitch", "busy_aisle"))
	if not pitches.has(pitch_id):
		push_error("Unknown pitch '%s'. Options: %s" % [pitch_id, pitches.keys()])
		quit(1)
		return

	if args.has("curve"):
		_print_queue_curve(types)

	var nights := int(args.get("nights", "5"))
	var base_seed := int(args.get("seed", "1"))
	var runs := {"as configured": float(args.get("show-every", "0"))}
	if args.has("compare"):
		runs = {"no show actions": 0.0, "show every 15 s": 15.0}

	for label in runs:
		var totals := {}
		var player_money := 0
		var rival_money := {}
		var passers := 0
		for n in nights:
			var sim := NightSimulator.new()
			sim.customer_types = types
			sim.pitch = pitches[pitch_id]
			sim.rivals = rivals
			sim.seed = base_seed + n
			sim.player.aroma = float(args.get("aroma", "0.7"))
			sim.player.frontage = float(args.get("frontage", "0.3"))
			sim.player.price_level = float(args.get("price", "0.5"))
			sim.player.serve_interval_s = float(args.get("serve", "12"))
			sim.player.show_burst = float(args.get("show-burst", "0.8"))
			sim.player.show_every_s = runs[label]
			if args.has("keep-grill-hot"):
				sim.player.idle_aroma_share = 1.0
			var report := sim.run()
			passers += report.passers
			for k in report.outcomes:
				totals[k] = totals.get(k, 0) + report.outcomes[k]
			for s in report.stalls:
				if s.id == &"player":
					player_money += s.revenue
				else:
					rival_money[s.id] = rival_money.get(s.id, 0) + s.revenue
		_print_summary(label, pitch_id, nights, passers, totals, player_money,
			rival_money, pitches[pitch_id].rent_per_night)
	quit()


func _print_summary(label: String, pitch_id: StringName, nights: int, passers: int,
		totals: Dictionary, player_money: int, rival_money: Dictionary, rent: int) -> void:
	print("")
	print("=== %s | pitch %s | %d nights | %d passers-by ===" % [label, pitch_id, nights, passers])
	print("Player outcomes (per night):")
	for k in ["won_from_rival", "won_uncontested", "lost_to_rival",
			"walked_past_everyone", "abandoned_your_queue", "went_elsewhere_uncontested"]:
		var v: float = float(totals.get(k, 0)) / nights
		var share: float = 100.0 * totals.get(k, 0) / max(passers, 1)
		print("  %-28s %6.1f   (%4.1f%% of passers-by)" % [k, v, share])
	print("Revenue per night: player %d (rent %d, so %d before ingredients)" % [
		player_money / nights, rent, player_money / nights - rent])
	for id in rival_money:
		print("                   %s %d" % [id, rival_money[id] / nights])


## Shows that the queue's net effect wq*Q(n) - wl*L rises, then falls,
## for a stall serving one customer every 12 s.
func _print_queue_curve(types: Array) -> void:
	print("Queue net effect wq*Q(n) - wl*L(n), serving every 12 s:")
	var header := "  n   "
	for t in types:
		header += "%-16s" % t.id
	print(header)
	for n in range(0, 11):
		var line := "  %-3d " % n
		for t in types:
			var c := CustomerData.create(t, 0)
			var s := StallData.new()
			s.queue_length = n
			s.avg_serve_s = 12.0
			var v: float = t.w_queue * StallSelector.queue_appeal(n) - t.w_wait * StallSelector.wait_penalty(c, s)
			line += "%+.3f          " % v
		print(line)


func _parse_args(raw: PackedStringArray) -> Dictionary:
	var out := {}
	for a in raw:
		if not a.begins_with("--"):
			continue
		var kv := a.substr(2).split("=", true, 1)
		out[kv[0]] = kv[1] if kv.size() > 1 else "true"
	return out
