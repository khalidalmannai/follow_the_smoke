extends SceneTree
## Unit tests for StallSelector. Exit code 0 = all passed.
##   godot --headless -s res://tools/test_stall_selector.gd

var _failures := 0
var _count := 0


func _init() -> void:
	test_picks_highest_utility()
	test_walks_past_when_nothing_noticed()
	test_full_queue_is_not_viable()
	test_queue_appeal_diminishes()
	test_wait_penalty_is_capped()
	test_queue_net_effect_rises_then_falls()
	test_long_queue_can_lose_to_short_queue()
	test_wont_join_queue_they_cannot_outlast()
	test_deterministic_for_same_seed()
	test_contested_vs_uncontested()
	test_simulator_is_deterministic()
	print("\n%d checks, %d failed" % [_count, _failures])
	quit(1 if _failures > 0 else 0)


# --- helpers ---------------------------------------------------------------

func _check(cond: bool, msg: String) -> void:
	_count += 1
	if not cond:
		_failures += 1
		print("FAIL: " + msg)


func _type(overrides: Dictionary = {}) -> CustomerTypeDef:
	var t := CustomerTypeDef.new()
	t.id = &"test"
	t.noise_fraction = 0.0
	t.tastes = PackedStringArray()
	for k in overrides:
		t.set(k, overrides[k])
	return t


func _stall(id: String, values: Dictionary = {}) -> StallData:
	var s := StallData.new()
	s.id = StringName(id)
	for k in values:
		s.set(k, values[k])
	return s


func _arr(list: Array) -> Array[StallData]:
	var out: Array[StallData] = []
	out.assign(list)
	return out


# --- tests -----------------------------------------------------------------

func test_picks_highest_utility() -> void:
	var c := CustomerData.create(_type(), 1)
	var weak := _stall("weak", {"aroma": 0.5})
	var strong := _stall("strong", {"aroma": 0.9})
	var chosen := StallSelector.select_stall(c, _arr([weak, strong]))
	_check(chosen != null and chosen.id == &"strong", "should pick the higher-aroma stall")


func test_walks_past_when_nothing_noticed() -> void:
	var c := CustomerData.create(_type({"notice_threshold": 0.5}), 1)
	var faint := _stall("faint", {"aroma": 0.1, "frontage": 0.1})
	var res := StallSelector.select(c, _arr([faint]))
	_check(res.noticed.is_empty(), "faint stall should not be noticed")
	_check(res.walked_past(), "customer should walk past")


func test_full_queue_is_not_viable() -> void:
	var c := CustomerData.create(_type(), 1)
	var full := _stall("full", {"aroma": 1.0, "queue_length": 8, "queue_cap": 8})
	var res := StallSelector.select(c, _arr([full]))
	_check(res.noticed.size() == 1, "a full stall can still be noticed")
	_check(res.walked_past(), "a full stall cannot be chosen")


func test_queue_appeal_diminishes() -> void:
	var q1 := StallSelector.queue_appeal(1) - StallSelector.queue_appeal(0)
	var q6 := StallSelector.queue_appeal(6) - StallSelector.queue_appeal(5)
	_check(q1 > q6 * 3.0, "first person in line should add far more appeal than the sixth")
	_check(StallSelector.queue_appeal(100) <= 1.0, "queue appeal is normalised to at most 1")


func test_wait_penalty_is_capped() -> void:
	var c := CustomerData.create(_type({"patience_s": 30.0}), 1)
	var s := _stall("s", {"queue_length": 20, "avg_serve_s": 12.0})
	_check(is_equal_approx(StallSelector.wait_penalty(c, s), 1.0), "wait penalty caps at 1")


func test_queue_net_effect_rises_then_falls() -> void:
	var t := _type({"w_queue": 1.0, "w_wait": 1.0, "patience_s": 60.0})
	var c := CustomerData.create(t, 1)
	var best_n := 0
	var best := -INF
	for n in range(0, 11):
		var s := _stall("s", {"queue_length": n, "avg_serve_s": 6.0})
		var v := StallSelector.queue_appeal(n) - StallSelector.wait_penalty(c, s)
		if v > best:
			best = v
			best_n = n
	_check(best_n > 0 and best_n < 10, "queue net effect should peak at a moderate length (got %d)" % best_n)


func test_long_queue_can_lose_to_short_queue() -> void:
	var c := CustomerData.create(_type({"w_wait": 1.0, "patience_s": 30.0}), 1)
	var busy := _stall("busy", {"aroma": 0.8, "queue_length": 6, "avg_serve_s": 10.0})
	var quiet := _stall("quiet", {"aroma": 0.6, "queue_length": 0, "avg_serve_s": 10.0})
	var res := StallSelector.select(c, _arr([busy, quiet]))
	_check(res.noticed.size() == 2, "customer should notice both stalls")
	_check(res.chosen != null and res.chosen.id == &"quiet",
		"impatient customer should prefer the shorter queue despite less aroma")


func test_wont_join_queue_they_cannot_outlast() -> void:
	var c := CustomerData.create(_type({"w_queue": 1.0, "patience_s": 30.0}), 1)
	var long_q := _stall("long", {"aroma": 1.0, "queue_length": 5, "avg_serve_s": 10.0})
	var res := StallSelector.select(c, _arr([long_q]))
	_check(res.walked_past(), "expected wait (50 s) beyond patience (30 s) means no join")


func test_deterministic_for_same_seed() -> void:
	var t := _type({"noise_fraction": 0.1})
	var a := _stall("a", {"aroma": 0.70})
	var b := _stall("b", {"aroma": 0.72})
	var first := StallSelector.select_stall(CustomerData.create(t, 42), _arr([a, b]))
	for i in 20:
		var again := StallSelector.select_stall(CustomerData.create(t, 42), _arr([b, a]))
		_check(again.id == first.id, "same seed must give the same choice regardless of stall order")


func test_contested_vs_uncontested() -> void:
	var c := CustomerData.create(_type(), 1)
	var mine := _stall("player", {"aroma": 0.9, "is_player": true})
	var rival := _stall("rival", {"aroma": 0.6})
	var res := StallSelector.select(c, _arr([mine, rival]))
	_check(res.chosen.is_player and res.had_rival_option(&"player"), "should be won from a rival")
	var alone := StallSelector.select(c, _arr([mine]))
	_check(alone.chosen.is_player and not alone.had_rival_option(&"player"), "should be won uncontested")


func test_simulator_is_deterministic() -> void:
	var r1 := _sim_once(7)
	var r2 := _sim_once(7)
	_check(r1.hash() == r2.hash(), "same seed must replay the same night")


func _sim_once(seed: int) -> Dictionary:
	var sim := NightSimulator.new()
	sim.customer_types = DefLoader.load_dir("res://data/customers")
	sim.pitch = DefLoader.load_by_id("res://data/pitches")[&"busy_aisle"]
	sim.rivals = DefLoader.load_dir("res://data/rivals")
	sim.seed = seed
	return sim.run()
